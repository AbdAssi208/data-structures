//id1:214074510 
//name1: Emad Khaled 
//username1: emadkhaled 
//id2:208147819 
//name2: Abdallah Assi 
//username2: Abdallhassi

import java.lang.Math;
/**
 * FibonacciHeap
 *
 * An implementation of Fibonacci heap over positive integers.
 *
 */
public class FibonacciHeap
{
	public HeapNode min;
	public int heapSize;
	public int numOfTrees;
	public int links;
	public int totalCuts;
	/**
	 *
	 * Constructor to initialize an empty heap.
	 *
	 */
	public FibonacciHeap()
	{
		this.min=null;
		this.heapSize=0;
		this.numOfTrees=0;
		this.links=0;
		this.totalCuts=0;
	}
	public FibonacciHeap(HeapNode node) {
		this.min=node;
		this.min.next=this.min;
		this.min.prev=this.min;
		this.heapSize=1;
		this.numOfTrees=1;
		this.links=0;
		this.totalCuts=0;
	}
	/**
	 * 
	 * pre: key > 0
	 *
	 * Insert (key,info) into the heap and return the newly generated HeapNode.
	 *
	 */
	public HeapNode insert(int key, String info) 
	{    
		HeapNode newNode=new HeapNode(key,info);
		FibonacciHeap newHeap=new FibonacciHeap(newNode);
		this.meld(newHeap);
		return newNode;
	}

	/**
	 * 
	 * Return the minimal HeapNode, null if empty.
	 *
	 */
	public HeapNode findMin()
	{
		return this.min; // should be replaced by student code
	}

	/**
	 * 
	 * Delete the minimal item
	 *
	 */
	public void deleteMin()
	{	
		HeapNode currentNode;
		// deleting a single-node tree ( the minimum node has 0 children)
		if(this.min == null) {
			return;
		}
		if(this.min.rank==0 && this.min.next==this.min) {
			this.min=null;
			this.heapSize=0;
			this.numOfTrees=0;
			return;
			
		}
		if(this.min.rank==0) {
			HeapNode prev=this.min.prev;
			HeapNode next=this.min.next;
			next.prev=prev;
			prev.next=next;
			this.min.next=null;
			this.min.prev=null;
			currentNode=next;
			this.numOfTrees-=1;
		}
		// otherwise the min node has at least one child :
		else {
			int theRank=this.min.rank;
			if(this.min.next==this.min) {
				currentNode=this.min.child;
				HeapNode r=currentNode.next;;
				while(r!=currentNode) {
					r.parent=null;
					r=r.next;
				}
				this.numOfTrees+=theRank;
				this.totalCuts+=theRank;

				
			}
			else {
			HeapNode x=this.min.child;
			HeapNode y=x.prev;
			HeapNode k=this.min.prev;
			HeapNode m=this.min.next;
			x.prev=k;
			k.next=x;
			y.next=m;
			m.prev=y;
			this.min.next=null;
			this.min.prev=null;
			currentNode=x;
			HeapNode iter=x.next;
			while(x!=iter) { // O(log n) in amortized
				iter.parent=null;
				iter=iter.next;
			}
			this.numOfTrees+=theRank;  // the children of the deleted node became roots of trees themselves
			this.totalCuts+=theRank;
		}
		}
			
		// finally, Consolidate starting from the current node that we have
		Consolidate(currentNode);
		this.heapSize-=1;
		
	}

	public void Consolidate(HeapNode node) {
	    // Step 1: Calculate the size of the bucket
	    int maxDegree = (int) Math.ceil((Math.log(heapSize + 1) / Math.log(2))); // Maximum possible degree
	    HeapNode[] buckets = new HeapNode[maxDegree + 1]; // Bucket array to store trees based on their degree

	    // Step 2: Traverse the root list and process each tree
	    HeapNode start = node; // Start at the given node
	    HeapNode current = start;
	    do {
	        HeapNode x = current; // Current tree to process
	        current = current.next; // Move to the next tree in the root list

	        // Detach x from the root list temporarily
	        x.prev = x.next = x;

	        // Step 3: Resolve conflicts in the bucket
	        while (buckets[x.rank] != null) {
	            HeapNode y = buckets[x.rank]; // Another tree with the same degree
	            buckets[x.rank] = null; // Clear the bucket slot

	            // Link x and y
	            x = this.LinkTrees(x, y); // Link the two trees; x becomes the parent
	        }

	        // Step 4: Place the resulting tree in the correct bucket
	        buckets[x.rank] = x;
	    } while (current != start);

	    // Step 5: Reconstruct the root list and update the minimum node
	    this.min = null;
	    this.numOfTrees = 0;
	    for (HeapNode tree : buckets) { // num of buckets= O(log(n+1))
	        if (tree != null) {
	            // Add the tree back to the root list
	            if (this.min == null) {
	                // First tree in the root list
	                this.min = tree;
	                tree.next = tree.prev = tree;
	            } else {
	                // Add to the circular doubly linked list
	                HeapNode minNext = this.min.next;
	                this.min.next = tree;
	                tree.prev = this.min;
	                tree.next = minNext;
	                minNext.prev = tree;

	                // Update the minimum pointer if needed
	                if (tree.key < this.min.key) {
	                    this.min = tree;
	                }
	            }
	            this.numOfTrees++; // Increment the count of trees
	        }
	    }
	}

	
	// link trees with equal degrees (number of children) !
	public HeapNode LinkTrees(HeapNode tree1,HeapNode tree2) {
		this.links += 1;
		// if both trees are single-node trees, avoid null child exception
		if (tree1.rank==0 && tree2.rank==0) {
			if(tree1.key <= tree2.key) {
				tree1.child=tree2;
				tree2.parent=tree1;
				tree1.rank=1;
				tree2.next=tree2.prev=tree2;
				return tree1;
			}
			else {
				tree2.child=tree1;
				tree1.parent=tree2;
				tree2.rank=1;
				tree1.next=tree1.prev=tree1;
				return tree2;
				}
		}
		// otherwise :
		if(tree1.key <= tree2.key) {
			HeapNode child =tree1.child;
			// then add tree2 to the same height node list as the child of tree1
			HeapNode next=child.next;
			child.next=tree2;
			tree2.prev=child;
			next.prev=tree2;
			tree2.next=next;
			tree2.parent=tree1;
			tree1.rank+=1;
			return tree1;
		}
		 
		else { // else, tree1.key > tree2.key :
			HeapNode child =tree2.child;
			// then add tree1 to the same height node list as the child of tree2
			HeapNode next=child.next;
			child.next=tree1;
			tree1.prev=child;
			next.prev=tree1;
			tree1.next=next;
			tree1.parent=tree2;
			tree2.rank+=1;
			return tree2; 
		}
	}
	/**
	 * 
	 * pre: 0<diff<x.key
	 * 
	 * Decrease the key of x by diff and fix the heap. 
	 * 
	 */
	public void decreaseKey(HeapNode x, int diff) // O(1)
	{    // if the node is a root, just decrease the key by diff and return
		if (x==null) {
			return;
		}
		if (x.parent == null) {
			 x.key-=diff;
			 if (x.key-diff < this.min.key) { // update the minimum if necessary
					this.min=x;
			 
			}
			 return;
		}
		 
		 if (x.key-diff < x.parent.key) { // violation occurred
		 	x.key-=diff;
		 	CascadingCut(x,x.parent);

		}
		 else { // if the difference still makes sense. don't change anything
			 x.key-=diff;

		 }
		 
		 if (x.key-diff < this.min.key) { // update the minimum if necessary
				this.min=x;
			}
	}
	public void CascadingCut(HeapNode x,HeapNode y) {
		cut(x,y);
		if (y.parent!= null) {
			if (y.mark==false) {
				y.mark=true;
			}
			else {
				CascadingCut(y,y.parent);
			}
		}
	}
	public void cut(HeapNode x,HeapNode y) {// cuts the sub-tree and adds it 
		this.totalCuts+=1;
		
		x.parent=null;
		x.mark=false;
		y.rank-=1;

		if (x.next==x) {
			y.child= null;
		}
		else {
			y.child = x.next;
			x.prev.next=x.next;
			x.next.prev=x.prev;
		}
		x.next=x.prev=x;
		// meld the tree into the tree root list
		HeapNode p=this.min.next;
		this.min.next=x;
		x.prev=this.min;
		p.prev=x;
		x.next=p;
		this.numOfTrees+=1; // we added one tree to the root list and the size of the tree didnt change
	}
	/**
	 * 
	 * Delete the x from the heap.
	 *
	 */
	public void delete(HeapNode x) 
	{    if (x==null) {
		return;
	}
		if (x == this.min) { // if the node is the minimum node, perform regular deletMin() function
			this.deleteMin();
		}
		else {// otherwise delete the node without consolidating because we already have a pointer to the min
			HeapNode minPointer=this.min; // keep our pointer to the min
			this.decreaseKey(x, x.key-this.min.key+1); // we get a key smaller than the min by 1

			// deleting a single node heap
			if(this.min.rank==0 && this.min.next==this.min) {
				this.min=null;
				this.heapSize=0;
				this.numOfTrees=0;
				return;
				
			}// deleting a single-node tree ( the minimum node has 0 children)
			if(this.min.rank==0) {
				HeapNode prev=this.min.prev;
				HeapNode next=this.min.next;
				next.prev=prev;
				prev.next=next;
				this.min.next=null;
				this.min.prev=null;
				this.numOfTrees-=1;
			}
			// otherwise the minimum node has at least one child :
			else {
				int theRank=this.min.rank;
				if(this.min.next==this.min) {
					HeapNode iter;
					iter=this.min.child;
					HeapNode r=iter.next;;
					while(r!=iter) {
						r.parent=null;
						r=r.next;
					}
					this.numOfTrees+=theRank;
					this.totalCuts+=theRank;
					
				}
				else {
				HeapNode q=this.min.child;
				HeapNode y=q.prev;
				HeapNode k=this.min.prev;
				HeapNode m=this.min.next;
				q.prev=k;
				k.next=q;
				y.next=m;
				m.prev=y;
				this.min.next=null;
				this.min.prev=null;
				HeapNode iter=q.next;
				while(q!=iter) { // O(log n) in amortized
					iter.parent=null;
					iter=iter.next;
				}
				this.numOfTrees+=theRank;  // the children of the deleted node became roots of trees themselves
				this.totalCuts+=theRank;
			}
			}
			this.heapSize-=1;
			this.min=minPointer;
		}
		
		
	}

	/**
	 * 
	 * Return the total number of links.
	 * 
	 */
	public int totalLinks()
	{
		return this.links; 
	}


	/**
	 * 
	 * Return the total number of cuts.
	 * 
	 */
	public int totalCuts()
	{
		return this.totalCuts; 
	}


	/**
	 * 
	 * Meld the heap with heap2
	 *
	 */
	/**
	 * 
	 * Meld the heap with heap2
	 *
	 */
	public void meld(FibonacciHeap heap2)
	{
	    // If the other heap is null or empty, do nothing
	    if (heap2 == null || heap2.min == null) {
	        return;
	    }
	    
	    // If the current heap is empty, adopt heap2 as the current heap
	    if (this.min == null) {
	        this.min = heap2.min;
	        this.heapSize = heap2.heapSize;
	        this.numOfTrees = heap2.numOfTrees;
	        this.totalCuts=heap2.totalCuts;
	        this.links=heap2.totalLinks();
	        return;
	    }
	    
	    if (this.numOfTrees==1 && heap2.numOfTrees==1) {
	    	this.min.next=heap2.min;
	    	this.min.prev=heap2.min;
	    	heap2.min.next=this.min;
	    	heap2.min.prev=this.min;
	    }
	    else if (this.numOfTrees==1) {
	    	this.min.next=heap2.min;
	    	HeapNode tmpPrev=heap2.min.prev;
	    	heap2.min.prev=this.min;
	    	tmpPrev.next=this.min;
	    	this.min.prev=tmpPrev;
	    }
	    else if (heap2.numOfTrees==1) {
	    	heap2.min.next=this.min;
	    	HeapNode tmpPrev=this.min.prev;
	    	this.min.prev=heap2.min;
	    	tmpPrev.next=heap2.min;
	    	heap2.min.prev=tmpPrev;	    	
	    }
	    else {
		    // Merge the root lists of the two heaps
		    HeapNode thisMinNext = this.min.next;
		    HeapNode heap2MinPrev = heap2.min.prev;
	
		    // Connect the two root lists
		    this.min.next = heap2.min;
		    heap2.min.prev = this.min;
		    
		    thisMinNext.prev = heap2MinPrev;
		    heap2MinPrev.next = thisMinNext;
	    }
	    // Update the minimum pointer if necessary
	    if (heap2.min.key < this.min.key) {
	        this.min = heap2.min;
	    }

	    // Update the heap size, number of trees ,totalinks and totalcuts
	    this.heapSize += heap2.heapSize;
	    this.numOfTrees += heap2.numOfTrees;
        this.totalCuts+=heap2.totalCuts;
        this.links+=heap2.totalLinks();
	}


	/**
	 * 
	 * Return the number of elements in the heap
	 *   
	 */
	public int size()
	{
		return this.heapSize;
	}
	

	/**
	 * 
	 * Return the number of trees in the heap.
	 * 
	 */
	public int numTrees()
	{
		return numOfTrees; 
	}

	/**
	 * Class implementing a node in a Fibonacci Heap.
	 *  
	 */
	public static class HeapNode{
		public int key;
		public String info;
		public HeapNode child;
		public HeapNode next;
		public HeapNode prev;
		public HeapNode parent;
		public int rank;
		public boolean mark;
		public HeapNode(int key,String info) {
			this.key=key;
			this.next=this;
			this.prev=this;
			this.info=info;
			this.rank=0;
		}
	}
}
