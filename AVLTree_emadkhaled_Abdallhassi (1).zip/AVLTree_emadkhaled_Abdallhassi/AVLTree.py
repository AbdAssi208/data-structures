#id1:214074510
#name1:Emad Khaled
#username1:emadkhaled
#id2:208147819
#name2:Abdallah Assi
#username2:Abdallhassi

class AVLNode(object):
    """
    Note:
    - We treat any node with key=None as a 'virtual' node (is_real_node=False).
    """


    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.left = None
        self.right = None
        self.parent = None
        self.height = -1  # by default, virtual nodes have height = -1

    def is_real_node(self):
        """Returns True if this node is a real (non-virtual) node, False otherwise."""
        return (self.key is not None)


class AVLTree(object):

    def __init__(self):
        self.root = None
        self.maxNode=None
        self.size_field = 0

    def search(self, key):
        """
        searches for a node whose key == key.
        returns (x, e):
        """
        if self.root is None:
            # empty tree => no real search path except "start/end" => e = 1
            return None, 0

        current = self.root
        edges = 0
        while current.is_real_node():
            edges += 1
            if current.key == key:
                return current, edges
            elif key < current.key:
                current = current.left
            else:
                current = current.right

        # reached a virtual node => not found
        return None, edges


    def finger_search(self, key):
        """
        Like search, but starts from the maximal node.
        """
        max_n = self.max_node()
        if max_n is None:
            return None, 0  # Empty tree
        else:
            if max_n.key<key:
                return None, 1
            elif max_n.key ==key:
                return max_n,1
        current = max_n
        edges = 0
        # if max has a left child, check him , if key found return it with e=1 , else add 1 to edges
        
        if current.left.is_real_node():
            if current.left.key == key:
                return current.left,1
            
        # Upward traversal
        while current.parent and current.parent.is_real_node() and current.parent.key >= key:
            current = current.parent
            edges += 1
            

            
        # Downward traversal
        while current.is_real_node():

            if current.key == key:
                return current, edges+1  # Found during downward traversal
            elif key < current.key:
                current = current.left
            else:
                current = current.right
            edges += 1

        return None, edges  # Not found


    def insert(self, key, val):
        """
        Insert a new node with (key, val) into the tree (keys are unique).
        Returns (x, e, h):
        """
        if self.root is None:
            # Tree is empty => new root is a real node
            new_node = AVLNode(key, val)
            new_node.height = 0
            new_node.left = AVLNode(None, None)  # Virtual children
            new_node.right = AVLNode(None, None)
            new_node.left.parent = new_node
            new_node.right.parent = new_node

            self.root = new_node
            self.maxNode = new_node  # Update maxNode for the first insertion
            self.size_field = 1
            return new_node, 0, 0  # e=1 (from root), h=0 (no promotes)

        # Standard BST insertion logic
        current = self.root
        edges = 0
        while current.is_real_node():
            edges += 1
            if key < current.key:
                if not current.left.is_real_node():
                    break
                current = current.left
            else:
                if not current.right.is_real_node():
                    break
                current= current.right

        # Create the new node
        new_node= AVLNode(key, val)
        new_node.height = 0
        new_node.left= AVLNode(None, None)
        new_node.right = AVLNode(None, None)
        new_node.left.parent= new_node
        new_node.right.parent = new_node

        new_node.parent= current
        if key < current.key:
            current.left= new_node
        else:
            current.right= new_node

        self.size_field += 1

        # Update maxNode if necessary
        if self.maxNode is None or key > self.maxNode.key:
            self.maxNode = new_node

        # Rebalance and count promotes only
        promotes = self.rebalance_and_count_promotes(current)
        return new_node, edges, promotes



    def finger_insert(self, key, val):
        """
        Insert a new node with (key, val) into the tree, starting from the maximal node.
        Returns (x, e, h):
        """

        # 1) Handle empty tree
        max_node = self.max_node()
        if max_node is None:
            # Same as inserting into an empty tree
            new_node = AVLNode(key, val)
            new_node.height = 0
            new_node.left = AVLNode(None, None)
            new_node.right = AVLNode(None, None)
            new_node.left.parent = new_node
            new_node.right.parent = new_node

            self.root = new_node
            self.size_field = 1
            self.maxNode = new_node  # This is now the max
            return new_node, 0, 0  # e=1 (from root), h=0 (no promotes)

        # 2) Handle case where key > maxNode.key
        if key > max_node.key:
            new_node = AVLNode(key, val)
            new_node.height= 0
            new_node.left = AVLNode(None, None)
            new_node.right= AVLNode(None, None)
            new_node.left.parent = new_node
            new_node.right.parent= new_node

            # Attach new node as the right child of the maxNode
            new_node.parent = max_node
            max_node.right= new_node

            # Update tree fields
            self.size_field += 1
            self.maxNode = new_node  # Update maxNode to the new node

            # Rebalance and count promotes
            promotes= self.rebalance_and_count_promotes(max_node)
            return new_node, 1, promotes  # e=1 (single edge to new node)

        # 3) Start from the maximal node for regular finger search insertion
        current = max_node
        edges = 0


        while current.parent and current.parent.is_real_node() and current.parent.key >= key:
            current = current.parent
            edges += 1


        # 4) Downward traversal: standard BST logic to find insertion spot
        while current.is_real_node():
            edges += 1  # each downward move
            if key < current.key:
                if not current.left.is_real_node():
                    break
                current = current.left
            else:
                if not current.right.is_real_node():
                    break
                current= current.right
        temp,edges= self.finger_search(current.key)
        # 5) Create and attach the new node
        new_node = AVLNode(key, val)
        new_node.height= 0
        new_node.left= AVLNode(None, None)
        new_node.right= AVLNode(None, None)
        new_node.left.parent = new_node
        new_node.right.parent = new_node
        new_node.parent= current

        if key < current.key:
            current.left = new_node
        else:
            current.right = new_node

        # 6) Update tree fields
        self.size_field += 1
        if self.maxNode is None or key > self.maxNode.key:
            self.maxNode = new_node
        
        # 7) Rebalance and count promotes
        promotes = self.rebalance_and_count_promotes(current)
        return new_node, edges, promotes






    def delete(self, node):
        """
        Delete 'node' from the tree.
        """
        if node is None or not node.is_real_node():
            return  # Nothing to do

        # Update maxNode if the deleted node is the current maxNode
        if node==self.maxNode:
            if node.left.is_real_node():
                # Find the new maxNode in the left subtree
                current =node.left
                while current.right.is_real_node():
                    current = current.right
                self.maxNode =current
            else:
                # No left subtree, use the parent as the new maxNode
                self.maxNode =node.parent if node.parent else None  # <-- One-line update here

        # Proceed with standard delete logic
        parent = node.parent

        # Case 1: node is a leaf (both children virtual)
        if not node.left.is_real_node() and not node.right.is_real_node():
            if parent is None:
                # Node was the root
                self.root = None
            else:
                # Remove leaf from parent
                if parent.left== node:
                    parent.left= AVLNode(None, None)
                    parent.left.parent = parent
                else:
                    parent.right= AVLNode(None, None)
                    parent.right.parent = parent
            self.size_field -= 1
            self.rebalance_and_count_promotes(parent)
            return

        # Case 2: node has exactly one real child
        if not node.left.is_real_node() or not node.right.is_real_node():
            child= node.left if node.left.is_real_node() else node.right
            if parent is None:
                # Node is root
                self.root = child
                child.parent = None
            else:
                if parent.left == node:
                    parent.left = child
                else:
                    parent.right = child
                child.parent = parent
            self.size_field -= 1
            self.rebalance_and_count_promotes(parent)
            return

        # case 3 where node has two real children
        successor = node.right
        while successor.left.is_real_node():
            successor= successor.left

        # Swap (key, value) with successor
        node.key, successor.key =successor.key, node.key
        node.value, successor.value = successor.value, node.value

        # Now 'successor' is either a leaf or has one real child => reuse logic
        self.delete(successor)



    def join(self, tree2, key, val):

        # Handle the case where both trees are empty
        if self.get_root() is None and tree2.get_root() is None:
            self.root= AVLNode(key, val)
            self.root.left = AVLNode(None, None)  # Virtual node
            self.root.right= AVLNode(None, None)  # Virtual node
            self.size_field = 1
            self.maxNode=self.get_root()
            self.get_root().height=0
            return

        # case where `self` is empty
        if self.get_root() is None:
            if tree2.get_root().key > key:
                tree2.insert(key,val)
            else:
                tree2.finger_insert(key,val)
            self.root=tree2.get_root()
            self.size_field= tree2.size()
            self.maxNode=tree2.max_node()
            return
        # Handle the case where `tree2` is empty
        elif tree2.get_root() is None:
            if self.get_root().key > key:
                self.insert(key,val)
            else:
                self.finger_insert(key,val)
            return

        #  checks if one tree's keys are all smaller than the other tree's keys
        if tree2.max_node().key < self.get_root().key:
            # Swap the trees and perform join on the opposite configuration
            tree2.join(self, key, val)
            self.root=tree2.get_root()
            self.maxNode=tree2.max_node()
            self.size_field=tree2.size()
            return
        #  case 2: Both trees are non-empty
        MAX_NODE=tree2.max_node()
        if self.get_root().height > tree2.get_root().height:
            # self is taller
            current= self.get_root()
            while current.right.is_real_node() and current.right.height > tree2.get_root().height:
                current= current.right

            # Insert the new root
            new_root= AVLNode(key, val)
            new_root.left =current.right
            new_root.right= tree2.get_root()
            if current.right.is_real_node():
                current.right.parent = new_root
            tree2.get_root().parent= new_root
            current.right = new_root
            new_root.parent = current

            # Rebalance upwards
            self.rebalance_and_count_promotes(new_root)

        elif self.get_root().height < tree2.get_root().height:
            # tree2  is taller
            current = tree2.get_root()
            while current.left.is_real_node() and current.left.height > self.get_root().height:
                current = current.left

            # Insert the new root
            new_root = AVLNode(key, val)
            new_root.right = current.left
            new_root.left = self.get_root()
            if current.left.is_real_node():
                current.left.parent = new_root
            self.get_root().parent = new_root
            current.left = new_root
            new_root.parent = current
            # Rebalance upwards
            tree2.rebalance_and_count_promotes(new_root)
        else:
            # Both trees have the same height
            new_root= AVLNode(key, val)
            
            new_root.left =self.get_root()
            new_root.right= tree2.get_root()
            self.get_root().parent= new_root
            tree2.get_root().parent = new_root
            self.root = new_root
            
            self.maxNode=MAX_NODE
            self.size_field = self.size() + tree2.size()+ 1

            return


        # Update the root and size of the resulting tree
        self.root = self.get_root() if self.get_root().height >= tree2.get_root().height else tree2.get_root()
        self.size_field = self.size() + tree2.size() + 1  # Correctly update the size
        self.maxNode=MAX_NODE


    def split(self, node):

        t1 = AVLTree()
        t2 = AVLTree()
        x_key = node.key

        # Initialize t1 with node.left
        if node.left.is_real_node():
            t1.root = node.left
            y = node.left
            while y.is_real_node():
                t1.maxNode = y
                y = y.right
                
        # Initialize t2 with node.right
        if node.right.is_real_node():
            t2.root = node.right
            y = node.right
            while y.is_real_node():
                t2.maxNode = y
                y = y.right


        # Now climb up from x's parent
        current = node.parent
        while current is not None:
            if current.key > x_key:
                # current.key < x_key => goes to t2
                right_sub =AVLTree()
                if current.right.is_real_node():
                    right_sub.root= current.right
                    y=right_sub.get_root()
                    while y.is_real_node():
                        right_sub.maxNode = y
                        y = y.right

                if not right_sub.root is None:
                    right_sub.root.parent=None
                t2.join(right_sub, current.key, current.value)

            else:
                # current.key < x_key => goes to t1
                left_sub =AVLTree()
                if current.left.is_real_node():
                    left_sub.root= current.left
                    y=left_sub.get_root()
                    while y.is_real_node():
                        left_sub.maxNode = y
                        y = y.right
                if not left_sub.root is None:
                    left_sub.root.parent=None


                t1.join(left_sub, current.key, current.value) 

                
            current=current.parent

                
        return t1, t2


    def avl_to_array(self):
        """Returns a sorted list of (key, value) by ascending key."""
        res = []
        self.inorder_to_array(self.root, res)
        return res

    def inorder_to_array(self, node, arr):
        if (node is None) or (not node.is_real_node()):
            return
        self.inorder_to_array(node.left, arr)
        arr.append((node.key, node.value))
        self.inorder_to_array(node.right, arr)


    def max_node(self):
        """Returns the real node with the maximal key, or None if the tree is empty."""
        return self.maxNode



    def size(self):
        """Returns the number of real nodes in the tree."""
        return self.size_field


    def get_root(self):
        """Returns the root of the tree if it's real and otherwise None."""
        if (self.root is None) or (not self.root.is_real_node()):
            return None
        return self.root



    def rebalance_and_count_promotes(self, node):
        """
        Rebalances the tree upwards from the given node and counts promote operations
        (height increases) before performing any balancing (rotations).
        Returns the number of promote operations (height increases).
        """
        promote_count = 0
        current = node

        while current is not None:
            old_h = current.height

            # Update height before balancing
            self.update_height(current)

            # Count promote if the height increases
            if current.height > old_h:
                promote_count += 1

            # Check balance factor
            bf = self.balance_factor(current)

            # Perform rotations if unbalanced
            if abs(bf) == 2:
                current = self.rotate_subtree(current)
                self.update_height(current.left)
                self.update_height(current.right)
                self.update_height(current)

            # Update the root if necessary
            if current.parent is None:
                self.root = current

            current = current.parent

        return promote_count



    def balance_factor(self, node):
        return (node.left.height - node.right.height)

    def update_height(self, node):
        if (node is not None) and (node.is_real_node()):
            node.height = 1 + max(node.left.height, node.right.height)

    def rotate_subtree(self, node):
        bf = self.balance_factor(node)

        # Left-heavy
        if bf == 2:
            # LR case?
            if self.balance_factor(node.left) < 0:
                self.rotate_left(node.left)
            return self.rotate_right(node)

        # Right-heavy
        if bf == -2:
            # RL case?
            if self.balance_factor(node.right) > 0:
                self.rotate_right(node.right)
            return self.rotate_left(node)

        return node

    def rotate_left(self, node):
        """
        left rotation around node.
        """
        pivot = node.right
        node.right = pivot.left
        if pivot.left.is_real_node():
            pivot.left.parent = node
        pivot.parent = node.parent
        if node.parent is not None:
            if node.parent.left== node:
                node.parent.left= pivot
            else:
                node.parent.right= pivot
                
                
        pivot.left= node
        node.parent = pivot
        
        return pivot

    def rotate_right(self, node):
        """
        right rotation around node.

        """
        
        pivot= node.left
        node.left= pivot.right
        
        if pivot.right.is_real_node():
            pivot.right.parent= node
        pivot.parent =node.parent
        
        if node.parent is not None:
            if node.parent.right== node:
                node.parent.right = pivot
            else:
                node.parent.left= pivot
        pivot.right= node
        
        node.parent = pivot
        
        return pivot



